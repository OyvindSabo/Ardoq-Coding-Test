# ChatBot
A chat bot which learns from its conversations, recognizing similar meaning of unlike sentences.
